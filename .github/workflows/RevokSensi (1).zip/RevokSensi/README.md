# Revok Sensi
Ajustes de sensibilidade, taxa de atualização e cor da tela via Shizuku ou root.
O APK é gerado em Actions > Build APK > Artifacts.
